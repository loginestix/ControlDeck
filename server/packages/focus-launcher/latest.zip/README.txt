Focus Launcher marketplace package for Control Deck.

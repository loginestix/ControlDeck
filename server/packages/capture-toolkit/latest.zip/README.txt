Capture Toolkit marketplace package for Control Deck.

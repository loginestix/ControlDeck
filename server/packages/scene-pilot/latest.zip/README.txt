Scene Pilot marketplace package for Control Deck.
